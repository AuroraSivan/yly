package Factory;

public class MapUtil {
	private static int carNum[]= {2,8};  //number of car in this level
	//private static int maxStep[]= {100,100};
	private static BackCar Map[][]=new BackCar[][] {
		{   //level 0,for showing rules
			new BackCar(0,1,3,true,2),
			new BackCar(1,4,1,false,3)
		},
		{   //level 1,for test
			new BackCar(0,2,3,true,2),
			new BackCar(1,1,5,false,2),
			new BackCar(2,1,2,false,3),
			new BackCar(3,1,1,true,2),
			new BackCar(4,3,6,true,3),
			new BackCar(5,5,5,true,2),
			new BackCar(6,6,1,false,3),
			new BackCar(7,4,2,false,3)
		}
	};
	
	public MapUtil() {
		
	}
	
	public BackCar[] getMap(int level)   //level表示第几关
	{
		int tempLevel=0;     //未补充其他地图，除第一关暂时使用规则页面地图
		if(level==1) 
			tempLevel=1;     
		int tempCarNum=carNum[tempLevel];
		BackCar[] temp=new BackCar[tempCarNum];
		for(int i=0;i<tempCarNum;i++)
		{
			temp[i]=Map[tempLevel][i];
		}
		return temp;
	}
	
	public int getCarNum(int level)
	{
		if(level==1)
			return carNum[1];
		else
			return carNum[0];
	}
	
	public int getMaxStep(int level)  //未实现，返回20便于测试
	{
		return 20;
	}
	
	public int getRecord(int level)   //未实现，返回9999
	{
		return 9999;
	}
	
	public void updateRecord(int level)  //未实现，空函数便于测试
	{
		
	}
	
	public boolean isUnlocked(int level)  
	//true when this level is unlocked,false when locked
	{
		if(level<4)          //前三关设置为已解锁，后三关设置为未解锁，方便测试
			return true;
		else
			return false;
	}
	
	public void unlockNewGame(int level)  //unlock this level，未实现，空函数便于测试
	{
		
	}
}