package Factory;

public class BackCar {
    private int id;    // if id==0.this car is the target car
    private int x;
    private int y;   //position point of the left or top
    private boolean direction; //true横放，false竖放
    private int length;
    
    public BackCar(int id,int x,int y,boolean direction,int length)
    {
    	this.id=id;
    	this.x=x;
    	this.y=y;
    	this.direction=direction;
    	this.length=length;
    }
    
    public void setId(int id) 
    {
    	this.id=id;
    }
    
    public int getId()
    {
    	return id;
    }
    
    public void setPos(int x,int y)  //set position
    {
    	this.x=x;
    	this.y=y;
    }
    
    public int getX() 
    {
    	return x;
    }
    
    public int getY() 
    {
    	return y;
    }
    
    public void setDirection(boolean direction)
    {
    	this.direction=direction;
    }
    
    public boolean getDirection()
    {
    	return direction;
    }
    
    public void setLength(int length)
    {
    	this.length=length;
    }
    
    public int getLength()
    {
    	return length;
    }
    
}

