package Factory;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
 
public class Car extends JButton /*implements FocusListener*/
{
	private int id;  //lzl:为了和BackCar连起来改了一下变量名,if id==0.this car is the target car
	Color c = new Color(255, 251, 170);
	Car(int number, String s) {
		super(s);
		setBackground(c);
		this.id = number;
		c = getBackground();
		//addFocusListener(this);
	}
	
	public int getId()   //lzl
	{
		return id;
	}
 
	/*public void focusGained(FocusEvent arg0) {
		//setBackground(Color.red);
	}//点击时变色
 
	public void focusLost(FocusEvent arg0) {
		//setBackground(c);
	} */
        //没有FocusListener效果没什么大的影响，所以删除
    
}
