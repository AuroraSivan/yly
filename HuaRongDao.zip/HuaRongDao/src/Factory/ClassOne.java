package Factory;

import java.awt.Rectangle;
import java.awt.event.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.imageio.ImageIO;
import javax.swing.Icon;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
 
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class ClassOne extends JFrame implements 
		MouseListener, MouseMotionListener {
	private int step=0;//步数  lzl:初始化由9999改为0
	private int recordStep=9999;   //
	private int maxstep;
	private int num;//主要用来检测冲突  
	private int level;//关卡数
	private boolean win=false;
	private int unitL = 100;//单元格边长，xyj
	
	ImageIcon[] icons=new ImageIcon[15];
	
	private BackCar map[];   
	private Car car[] = new Car[17]; //maybe more than 12
	
	public ClassOne(int i) {
		level=i;
		getIcons();
		init();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//只关闭当前窗口,xyj微调
		setSize(unitL*10, (int) (unitL*6.8));
        setLocationRelativeTo(null);

		setVisible(true);
		validate();
	}
 
	private static ImageIcon loadImageIcon(String filePath, int width, int height) {
        ImageIcon originalIcon = new ImageIcon(filePath);
        Image image = originalIcon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(image);
    }
	
	private void getIcons() {
		for(int i=0;i<15;i++) {
			if(i==1||i==2) {
				icons[i]=loadImageIcon("picture/car"+i+".jpg",3*unitL,unitL);
			}
			else if(i==8||i==9) {
				icons[i]=loadImageIcon("picture/car"+i+".jpg",unitL,3*unitL);
			}
			else if(i>9&&i<15) {
				icons[i]=loadImageIcon("picture/car"+i+".jpg",unitL,2*unitL);
			}
			else {
				icons[i]=loadImageIcon("picture/car"+i+".jpg",2*unitL,unitL);
			}
		}
		repaint();
	}
	
	public void init() {
		ImageIcon image = new ImageIcon("src/background.jpg");//import new image
		image.setImage(image.getImage().getScaledInstance(unitL*10, (int) (unitL*6.8), DEFAULT_CURSOR));//这里还没搞定，等待贴图
        JLabel backgroundLabel = new JLabel(image);
        
        setContentPane(backgroundLabel);
        backgroundLabel.setBounds(0,0,unitL*10, (int) (unitL*6.8));
        backgroundLabel.setLayout(null);
        backgroundLabel.setVisible(true);
        
        MapUtil initUtil=new MapUtil();  //lzl:initial variable 
        map=initUtil.getMap(level);
        num=initUtil.getCarNum(level);
        recordStep=initUtil.getRecord(level);
        maxstep=initUtil.getMaxStep(level);
        
		car[0] = new Car(0,"a");
		car[0].addMouseListener(this);
		car[0].addMouseMotionListener(this);
		car[0].setIcon(icons[0]);//try to set pictures
		
		backgroundLabel.add(car[0]);
		for (int k = 1; k < num; k++) {
			int id=map[k].getId();
			car[k]=new Car(k,Integer.toString(map[k].getId()));  //lzl:change to String,easy to see
			car[k].addMouseListener(this);
			car[k].addMouseMotionListener(this);
			if(map[k].getDirection())car[k].setIcon(icons[id]);//set pictures,横放
			else car[k].setIcon(icons[id+7]);//竖放
			backgroundLabel.add(car[k]);
		}
		
		for(int i=0;i<num;i++)         //lzl:place cars as map
		{
			int tempX=map[i].getX(), tempY=map[i].getY();
			int tempL=map[i].getLength();
			if(map[i].getDirection())    //横放
			{
				car[i].setBounds( (tempX-1)*unitL, (tempY-1)*unitL, tempL*unitL, unitL);
				//car[i].setIcon(icons[])
			}
			else
			{
				car[i].setBounds( (tempX-1)*unitL, (tempY-1)*unitL, unitL, tempL*unitL);
			}
		}
	
		validate();
	}
	
	public boolean getWin()   //lzl
	{
		return win;
	}
	
 	private int OriginalX, OriginalY; //original x and y of mouse when pressing(lzl)
 	private int xDistance=0, yDistance=0;  //distance from new x and y to the original when dragging mouse(lzl)
 	private int width,height;        //lzl改
 	private int getX , getY;
 	private int maxdx;
 	private int maxdy;
 	private Car choose;
	private boolean premove = false ;//判断是否移动到靠边

	public void mousePressed(MouseEvent e) {
		maxdx=unitL*6;maxdy=unitL*6;
		choose = (Car) e.getSource();
		OriginalX = e.getX();//x of mouse in the button
		OriginalY = e.getY();
		getX = choose.getX();
		getY = choose.getY();
		width = choose.getBounds().width;
		height = choose.getBounds().height;
	}
 
	
	public void mouseReleased(MouseEvent e) {

		int newX , newY;
		float a = (float) (choose.getX()/(float) unitL);
		newX = Math.round(a)*unitL;
		float b = (float) (choose.getY()/(float) unitL);
		newY= Math.round(b)*unitL;
		choose.setLocation(newX,newY);
		if(car[0].getX()==unitL*4){
			win=true;
			JOptionPane.showMessageDialog( null,"you win!");
			dispose();
			}
		if(newX!=getX || newY!=getY)step++;
		if(step==maxstep){
			JOptionPane.showMessageDialog( null,"you lose!");
			dispose();//step 超过设定即失败
		}
		xDistance=0;
		yDistance=0;
	}
	
	public void mouseDragged(MouseEvent e) {
		
		xDistance = e.getX()-OriginalX;//movement of mouse when drag
        yDistance = e.getY()-OriginalY;
        go(choose);
        repaint();
	}

	
	public void go(Car man) {//检测是否能挪动
		boolean move = true;
		Rectangle manRect = man.getBounds();
		int x = man.getBounds().x;
		int y = man.getBounds().y;
		if (width==unitL)
			y = y + yDistance;
		else if (height==unitL)
			x = x + xDistance;
		manRect.setLocation(x, y);
		for (int k = 0; k < num; k++) {
			Rectangle carRect = car[k].getBounds();
			if (manRect.intersects(carRect)&& man.getId()!=k){//检测方块重叠
				move = false;
				if (width==unitL)
					maxdy=yDistance;
				else if (height==unitL)
					maxdx=xDistance;
				if(premove==true){
					if(x>getX)
						man.setLocation(x/unitL*unitL,y);	
					else if(x<getX)
						man.setLocation((x/unitL+1)*unitL,y);
					else if(y>getY)
						man.setLocation(x,y/unitL*unitL);	
					else if(y<getY)
						man.setLocation(x,(y/unitL+1)*unitL);
					premove = false ;//避免接近方块时拖拽滞涩，xyj
					}
	
			}
		}
		if (x<0||y<0||x>unitL*6-width||y>unitL*6-height){
			move = false;
			if(premove==true){
				if(x!=getX)
					man.setLocation(x/unitL*unitL,y);	
				else if(y!=getY)
					man.setLocation(x,y/unitL*unitL);	
				premove = false ;//避免接近边框时拖拽滞涩,xyj
			}

		}
			
		if(maxdx*(maxdx-xDistance)<0 )move = false;
		if(maxdy*(maxdy-yDistance)<0 )move = false;//避免隔山打牛bug
		//简化为两行，xyj微调
		
		if (move == true){
			premove = true;
			man.setLocation(x, y);	
		}
	}


	
	public void mouseClicked(MouseEvent e) {   //改变了空函数在代码文件中的位置，方便阅读（lzl)
	}
 
	public void mouseEntered(MouseEvent e) {
	}
 
	public void mouseExited(MouseEvent e) {
	}

	public void mouseMoved(MouseEvent e) {
	}


}