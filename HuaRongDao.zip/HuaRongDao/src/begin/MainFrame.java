package begin;


public class MainFrame {
	public static void main(String[] args) {
		BeginFrame begin = new BeginFrame();
	}
}
