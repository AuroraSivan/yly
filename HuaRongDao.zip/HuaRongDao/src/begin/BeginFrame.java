package begin;
import javax.imageio.ImageIO;
import javax.swing.*;

import Factory.ClassOne;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class BeginFrame {
    private JFrame mainFrame;
    private JFrame rulesFrame;
    private JFrame levelFrame;
    private CardLayout cardLayout;
    private JPanel levelPanel;

    private int currentLevel = 1;

    public BeginFrame(){
    	SwingUtilities.invokeLater(new Runnable() {
    	    public void run() {
    	        createAndShowGUI();
    	    }
    	});
    }//改为类

    private void createAndShowGUI() {
        mainFrame = new JFrame("开始游戏");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImageIcon backgroundImage = new ImageIcon("picture/begin.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        mainFrame.setContentPane(backgroundLabel);
        mainFrame.setLayout(new GridBagLayout());
        
        JButton startButton = new JButton("开始游戏");
        startButton.setFont(new  java.awt.Font("宋体", 1, 15)); 
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	showLevelSelection();
            }
        });

        JButton exitButton = new JButton("退出游戏");
        exitButton.setFont(new  java.awt.Font("宋体", 1, 15)); 
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int result = JOptionPane.showConfirmDialog(mainFrame,"确认退出游戏吗？", "确认退出", JOptionPane.YES_NO_OPTION);
                if (result == JOptionPane.YES_OPTION) {
                    System.exit(0); // 退出程序
                }
            }
        });
        
        JButton ruleButton = new JButton("游戏规则");
        ruleButton.setFont(new  java.awt.Font("宋体", 1, 15)); 
        ruleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showRules();
            }
        });
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 0, 0, 0); // Add some top margin
        mainFrame.add(startButton, gbc);

        GridBagConstraints gbcExit = new GridBagConstraints();
        gbcExit.gridx = 0;
        gbcExit.gridy = 2;
        gbcExit.insets = new Insets(10, 0, 0, 0);
        mainFrame.add(exitButton, gbcExit);
        
        GridBagConstraints gbcRule = new GridBagConstraints();
        gbcRule.gridx = 0;
        gbcRule.gridy = 3;
        gbcRule.insets = new Insets(10, 0, 0, 0);
        mainFrame.add(ruleButton, gbcRule);
        
        mainFrame.setSize(1000,680);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }
    
    private void showRules() {
        rulesFrame = new JFrame("游戏规则");
        rulesFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JButton continueButton = new JButton("返回");
        continueButton.setFont(new  java.awt.Font("仿宋",1,15)); 
        continueButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                rulesFrame.dispose();
            }
        });

        JLabel rulesLabel = new JLabel("<html>在格线内移动所有可以移动的小车，<br>最终移出目标小车</html>");
        rulesLabel.setFont(new java.awt.Font("仿宋",1,35)); 
        rulesLabel.setForeground(Color.black);
        rulesLabel.setHorizontalAlignment(JLabel.CENTER);

        ImageIcon backgroundImage2 = new ImageIcon("picture/guize.jpg");
        JLabel backgroundLabel2 = new JLabel(backgroundImage2);
        rulesFrame.setContentPane(backgroundLabel2);
        
        rulesFrame.setLayout(new BorderLayout());
        rulesFrame.add(rulesLabel, BorderLayout.CENTER);
        rulesFrame.add(continueButton, BorderLayout.SOUTH);

        rulesFrame.setSize(1000,680);
        rulesFrame.setLocationRelativeTo(mainFrame);
        rulesFrame.setVisible(true);
    }

 
    
    private void showLevelSelection() {
        levelFrame = new JFrame("关卡选择");
        levelFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        levelPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        //LevelButton[] levelButton=new LevelButton[5];
        for (int i = 1; i <= 6; i++) {
        	final int level = i;
        	String imagePath = null;
        	if(!isUnlocked(level)) {
        		imagePath = "picture/unlocked.jpg";
        	}
        	else {
        		imagePath = "picture/" + i + ".jpg";
        	}
        	LevelButton levelButton = new LevelButton("第" + i + "关",imagePath);
            levelButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (isUnlocked(level)) {
                        // Do something when the level is unlocked
                    	ClassOne c= new ClassOne(level);
                    	if(c.getWin()==true);      //win改成getWin（）
                    	setLevelUnlocked(level+1);
                    } else {
                        JOptionPane.showMessageDialog(levelFrame, "请先解锁前面关卡");
                    }
                }
            });

            levelPanel.add(levelButton);
        }
//levelButton.setButtonImage("C:/Users/31067/Desktop/picture/" + level + ".jpg");
        // Initially set the first level as unlocked
        
        /*private class LevelButtonListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton sourceButton = (JButton) e.getSource();
                String level = sourceButton.getText();
                JOptionPane.showMessageDialog(Test.this, "你选择了" + level);
            }
        }*/
        JButton backButton = new JButton("返回");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                levelFrame.dispose();
            }
        });

        levelFrame.setLayout(new BorderLayout());
        levelFrame.add(levelPanel, BorderLayout.CENTER);
        levelFrame.add(backButton, BorderLayout.SOUTH);

        levelFrame.setSize(1000,680);
        levelFrame.setLocationRelativeTo(mainFrame);
        levelFrame.setVisible(true);
    }
    
    private boolean isUnlocked(int level) {
        // Check if the level is unlocked based on the current level
        return level <= currentLevel;
    }

    private void setLevelUnlocked(int level) {
        // Set the given level as unlocked
        currentLevel = level;
    }
    
 // 自定义按钮类，用于设置背景图片和显示文字
    private class LevelButton extends JButton {
        public LevelButton(String text, String imagePath) {
            super();
            setLayout(new BorderLayout());
            setOpaque(false);
            setContentAreaFilled(false);
            setBorderPainted(false);

            // 在按钮上方添加文字
            JLabel textLabel = new JLabel(text);

            //设置文字的字体大小和颜色
            Font originalFont = textLabel.getFont();
            Font newFont = new Font(originalFont.getName(), originalFont.getStyle(),30); 
            textLabel.setFont(newFont);

            textLabel.setForeground(Color.YELLOW);

            textLabel.setHorizontalAlignment(JLabel.CENTER);
            add(textLabel, BorderLayout.CENTER);

            // 设置背景图片并调整大小以适应按钮
            SwingUtilities.invokeLater(() -> {
                ImageIcon originalIcon = new ImageIcon(loadImage(imagePath));
                Image scaledImage = originalIcon.getImage().getScaledInstance(getWidth(), getHeight(), Image.SCALE_SMOOTH);
                setIcon(new ImageIcon(scaledImage));
            });
        }

        /*public void setButtonImage(String imagePath) {
            SwingUtilities.invokeLater(() -> {
                ImageIcon originalIcon = new ImageIcon(loadImage(imagePath));
                Image scaledImage = originalIcon.getImage().getScaledInstance(getWidth(), getHeight(), Image.SCALE_SMOOTH);
                setIcon(new ImageIcon(scaledImage));
            });
        }*/
        
        private BufferedImage loadImage(String filePath) {
            try {
                return ImageIO.read(new File(filePath));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

    }
 // 读取图片
    private static ImageIcon loadImageIcon(String filePath, int width, int height) {
        ImageIcon originalIcon = new ImageIcon(filePath);
        Image image = originalIcon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(image);
    }
}
